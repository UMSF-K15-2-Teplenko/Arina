﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laba2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Завдання 1");
            Console.Write("Введите значение x: ");
            double x = double.Parse(Console.ReadLine());
            Console.Write("Значение функции\n");
            Console.WriteLine("у= {0}", (1 / (Math.Pow(x, 2) - 1)));
            Console.WriteLine("-------------------------------");
            Console.WriteLine("\nЗавдання 3");
            Console.Write("Введите число от 1 до 4, чтобы узнать масть: ");
            int m = int.Parse(Console.ReadLine());
            switch (m)
            {
                case 1: Console.WriteLine("Пики");break;
                case 2: Console.WriteLine("Трефы"); break;
                case 3: Console.WriteLine("Бубны"); break;
                case 4: Console.WriteLine("Червы"); break;
            }
            Console.WriteLine("-------------------------------");
            Console.WriteLine("\nЗавдання 5");
            for (int i = 1; i <= 4; i ++)
            {
                for (int j = 1; j <=10; j++)
                    Console.Write("{0, 3}", j);
                Console.WriteLine();
            }
            Console.ReadKey();

        }
    }
}
