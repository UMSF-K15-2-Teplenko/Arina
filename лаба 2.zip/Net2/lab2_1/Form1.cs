﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab2_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void zbtProblem2_Click(object sender, EventArgs e)
        {
            try
            {
                int x = int.Parse(textBox1.Text);
                int y = int.Parse(textBox2.Text);
                int R = 7;
                int r = 3;
                if ((x*x + y*y > r*r) && (x*x + y*y < R*R))
                    zlaProblem2.Text = "Точка належить області";
                else if ((x * x + y * y < r * r) || (x * x + y * y > R * R))
                    zlaProblem2.Text = "Точка не належить області";
                else zlaProblem2.Text = "Точка знаходиться на границі";
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректні дані!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void zbtProblem6_Click(object sender, EventArgs e)
        {
            try
            {
                double a = double.Parse(textBox6.Text);
                double b = double.Parse(textBox7.Text);
                double h = double.Parse(textBox8.Text);
                zlbProblem6.Items.Clear();
                zlbProblem6.Items.Add("    x\t|    y");
                for (double x = a; x <= b; x += h)
                {
                    double y;
               
                    if (Math.Abs(x) < 3)
                    {
                        y = Math.Sin(x);
                    }
                    else if (Math.Abs(x) >= 3 && Math.Abs(x) < 9)
                    {
                        y = Math.Sqrt((Math.Pow(x, 2) + 1)) / Math.Sqrt((Math.Pow(x, 2) + 5));
                    }
                    else
                    {
                        y = Math.Sqrt(Math.Pow(x, 2) + 1) - Math.Sqrt(Math.Pow(x, 2) + 5);
                    }
                    zlbProblem6.Items.Add(String.Format("  {0,2:F}\t|  {1,2:F}", x, y));
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректні дані!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void zbtProblem4_Click(object sender, EventArgs e)
        {
            try
            {
                int A = int.Parse(textBox3.Text);
                int B = int.Parse(textBox4.Text);
                int X = int.Parse(textBox9.Text);
                int Y = int.Parse(textBox10.Text);
                string s = ""; 
                if (A > B)
                {
                    ztbProblem4.Text = "Потрібні числа відсутні!";
                }
                else
                {
                    for (int i = A; i <= B; i++)
                    {
                        if ((i % 10 == X) || (i % 10 == Y))
                            s += i.ToString() + " ";
                    }
                    ztbProblem4.Text = s;
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Некорректні дані!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
